import os
import sys
import pygame

pygame.init()
size = width, height = 300, 300
screen = pygame.display.set_mode(size)
pygame.display.set_caption('Герой двигается!')


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname).convert()
    if colorkey is not None:
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


x, y = 0, 0
running = True
my_image = load_image('creature.png')
clock = pygame.time.Clock()
fps = 60
px = 10
while running:
    screen.fill((255, 255, 255))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        x -= px
    elif keys[pygame.K_RIGHT]:
        x += px
    elif keys[pygame.K_DOWN]:
        y += px
    elif keys[pygame.K_UP]:
        y -= px
    screen.blit(my_image, (x, y))
    clock.tick(fps)
    pygame.display.flip()
pygame.quit()
